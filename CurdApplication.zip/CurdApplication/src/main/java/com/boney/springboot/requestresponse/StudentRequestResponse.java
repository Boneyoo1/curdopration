package com.boney.springboot.requestresponse;

import org.springframework.stereotype.Component;

@Component
public class StudentRequestResponse {

	private String StudentFirstName;

	private String lastName;

	private String email;

	private String password;

	public String getStudentFirstName() {
		return StudentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		StudentFirstName = studentFirstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "StudentRequestResponse [StudentFirstName=" + StudentFirstName + ", lastName=" + lastName + ", email="
				+ email + ", password=" + password + "]";
	}

}
