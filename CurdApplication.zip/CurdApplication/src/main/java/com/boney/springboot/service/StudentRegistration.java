package com.boney.springboot.service;

import com.boney.springboot.requestresponse.StudentRequestResponse;

public interface StudentRegistration {

	public void doRegisration(StudentRequestResponse student);
}
